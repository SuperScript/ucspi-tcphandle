#ifndef READWRITE_H
#define READWRITE_H

extern int read();
extern int write();

#endif
