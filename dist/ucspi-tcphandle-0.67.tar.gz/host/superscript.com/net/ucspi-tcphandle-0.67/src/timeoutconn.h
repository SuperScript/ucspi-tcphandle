#ifndef TIMEOUTCONN_H
#define TIMEOUTCONN_H

#include "uint16.h"

extern int timeoutconn(int,char *,uint16,unsigned int);

#endif
